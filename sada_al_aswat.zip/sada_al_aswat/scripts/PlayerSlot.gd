extends Control
class_name PlayerSlot

@onready var score_label: Label = $ScoreLabel
@onready var avatar: ColorRect = $Avatar
@onready var name_label: Label = $NameLabel

var player_id: int = 0
var base_score_y: float = 0.0

func _ready() -> void:
	base_score_y = score_label.position.y

func set_player_id(id: int) -> void:
	player_id = id
	name_label.text = "اللاعب %d" % (id + 1)

func set_active(is_active: bool) -> void:
	if is_active:
		avatar.color = Color(1.0, 0.8, 0.2)
		scale = Vector2(1.1, 1.1)
	else:
		avatar.color = Color(0.3, 0.6, 0.9)
		scale = Vector2(1.0, 1.0)

func mark_winner() -> void:
	avatar.color = Color(0.3, 0.9, 0.4)
	scale = Vector2(1.2, 1.2)

## يعرض النسبة فوق رأس اللاعب مع حركة ظهور وارتفاع بسيطة
func show_score(percentage: float) -> void:
	score_label.text = "%d%%" % roundi(percentage)
	score_label.modulate.a = 0.0
	score_label.position.y = base_score_y + 20.0
	var tw := create_tween()
	tw.tween_property(score_label, "modulate:a", 1.0, 0.3)
	tw.parallel().tween_property(score_label, "position:y", base_score_y, 0.3)

func clear_score() -> void:
	score_label.text = ""
	avatar.color = Color(0.3, 0.6, 0.9)
	scale = Vector2(1.0, 1.0)
