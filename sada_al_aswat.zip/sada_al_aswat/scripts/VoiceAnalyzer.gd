extends RefCounted
class_name VoiceAnalyzer
## يحسب نسبة مطابقة حقيقية بين صوتين بالاعتماد على:
##  1) التردد الأساسي / طبقة الصوت (Pitch)                 وزن 35%
##  2) شكل الطيف الترددي عبر FFT (بصمة الصوت/الطابع)        وزن 35%
##  3) مغلّف الطاقة عبر الزمن (إيقاع الأداء)                 وزن 20%
##  4) تقارب المدة الزمنية                                   وزن 10%
## لا يوجد أي عنصر عشوائي هنا - النتيجة تعتمد بالكامل على العينات الصوتية الفعلية.
##
## ملاحظة مهمة: هذه الدالة لا تقرأ ملفات wav مباشرة، بل تستقبل مصفوفات عينات
## (PackedFloat32Array) جاهزة تم التقاطها عبر AudioCapture.gd من محرك الصوت
## نفسه أثناء التشغيل/التسجيل. هذا هو ما يجعل التحليل يعمل مع أي صيغة صوت
## يدعمها Godot (wav, mp3, ogg) دون أي تفريق بينها - فك التشفير يتم داخل
## محرك الصوت قبل أن تصل العينات إلى هنا أصلًا.

const TARGET_RATE := 16000
const FRAME_SIZE := 1024
const HOP_SIZE := 512
const MIN_PITCH_HZ := 70.0
const MAX_PITCH_HZ := 500.0
const SILENCE_RMS := 0.015
const SPECTRUM_BINS := 24
const ENVELOPE_POINTS := 24

static func compute_similarity(
	original_samples: PackedFloat32Array,
	original_rate: int,
	attempt_samples: PackedFloat32Array,
	attempt_rate: int
) -> float:
	if original_samples.size() < 256 or attempt_samples.size() < 256:
		return 0.0

	var a := _to_target_rate(original_samples, original_rate)
	var b := _to_target_rate(attempt_samples, attempt_rate)

	a = _trim_silence(a)
	b = _trim_silence(b)
	if a.size() < 256 or b.size() < 256:
		return 0.0

	var pitch_a: float = _average_pitch(a)
	var pitch_b: float = _average_pitch(b)
	var spec_a := _average_spectrum(a)
	var spec_b := _average_spectrum(b)
	var env_a := _energy_envelope(a, ENVELOPE_POINTS)
	var env_b := _energy_envelope(b, ENVELOPE_POINTS)

	var score_pitch: float = _pitch_score(pitch_a, pitch_b)
	var score_spectral: float = _cosine_similarity(spec_a, spec_b)
	var score_envelope: float = _envelope_score(env_a, env_b)
	var score_duration: float = _duration_score(a.size(), b.size())

	var total: float = score_pitch * 0.35 + score_spectral * 0.35 + score_envelope * 0.20 + score_duration * 0.10
	return clampf(total, 0.0, 1.0) * 100.0

static func _to_target_rate(samples: PackedFloat32Array, rate: int) -> PackedFloat32Array:
	if rate == TARGET_RATE or samples.size() == 0:
		return samples
	return _resample(samples, rate, TARGET_RATE)

## مفصولة في دالتها الخاصة بأنواع صريحة بالكامل لتفادي أي التباس في الاستنتاج
static func _duration_score(size_a: int, size_b: int) -> float:
	var diff: int = absi(size_a - size_b)
	var largest: int = maxi(maxi(size_a, size_b), 1)
	var ratio: float = float(diff) / float(largest)
	return 1.0 - clampf(ratio, 0.0, 1.0)

# ==================== إعادة أخذ العينات (Resampling) ====================

static func _resample(samples: PackedFloat32Array, from_rate: int, to_rate: int) -> PackedFloat32Array:
	if from_rate == to_rate or samples.size() == 0:
		return samples
	var ratio: float = float(from_rate) / float(to_rate)
	var new_len: int = int(samples.size() / ratio)
	var out := PackedFloat32Array()
	out.resize(new_len)
	for i in new_len:
		var src_pos: float = i * ratio
		var i0: int = int(src_pos)
		var i1: int = mini(i0 + 1, samples.size() - 1)
		var frac: float = src_pos - i0
		out[i] = lerp(samples[i0], samples[i1], frac)
	return out

# ==================== المعالجة الأولية ====================

static func _rms(samples: PackedFloat32Array, from: int, length: int) -> float:
	var n: int = mini(length, samples.size() - from)
	if n <= 0:
		return 0.0
	var sum := 0.0
	for i in n:
		var s := samples[from + i]
		sum += s * s
	return sqrt(sum / n)

static func _trim_silence(samples: PackedFloat32Array) -> PackedFloat32Array:
	var window := 256
	var start := 0
	var end := samples.size()
	var i := 0
	while i + window < samples.size():
		if _rms(samples, i, window) > SILENCE_RMS:
			start = i
			break
		i += window
	i = samples.size() - window
	while i > start:
		if _rms(samples, i, window) > SILENCE_RMS:
			end = i + window
			break
		i -= window
	if end <= start:
		return samples
	return samples.slice(start, end)

static func _apply_hamming(frame: PackedFloat32Array) -> PackedFloat32Array:
	var out := PackedFloat32Array()
	out.resize(frame.size())
	var n := frame.size()
	var denom: float = float(maxi(1, n - 1))
	for i in n:
		var w: float = 0.54 - 0.46 * cos(2.0 * PI * i / denom)
		out[i] = frame[i] * w
	return out

# ==================== طبقة الصوت (Pitch) ====================

static func _average_pitch(samples: PackedFloat32Array) -> float:
	var pitches: Array[float] = []
	var i := 0
	while i + FRAME_SIZE <= samples.size():
		var frame := samples.slice(i, i + FRAME_SIZE)
		if _rms(frame, 0, frame.size()) > SILENCE_RMS:
			var p: float = _detect_pitch(frame)
			if p > 0.0:
				pitches.append(p)
		i += HOP_SIZE
	if pitches.is_empty():
		return 0.0
	pitches.sort()
	var mid: int = pitches.size() >> 1
	return pitches[mid] # الوسيط (median) أكثر ثباتًا من المتوسط

## كشف التردد الأساسي عبر الارتباط الذاتي (Autocorrelation) - طريقة معيارية وواقعية
static func _detect_pitch(frame: PackedFloat32Array) -> float:
	var windowed := _apply_hamming(frame)
	var min_lag: int = int(TARGET_RATE / MAX_PITCH_HZ)
	var max_lag: int = mini(int(TARGET_RATE / MIN_PITCH_HZ), windowed.size() - 1)
	var best_lag := -1
	var best_val := 0.0
	for lag in range(min_lag, max_lag + 1):
		var sum := 0.0
		var n := windowed.size() - lag
		for i in n:
			sum += windowed[i] * windowed[i + lag]
		if sum > best_val:
			best_val = sum
			best_lag = lag
	if best_lag <= 0:
		return 0.0
	return TARGET_RATE / float(best_lag)

## يقيس الفرق بالـ"سيمي تون" (وحدة موسيقية) بين الطبقتين - أدق من الفرق الخام بالهرتز
static func _pitch_score(p1: float, p2: float) -> float:
	if p1 <= 0.0 or p2 <= 0.0:
		return 0.3
	var semitone_diff: float = 12.0 * (log(p1 / p2) / log(2.0))
	return clampf(1.0 - absf(semitone_diff) / 12.0, 0.0, 1.0)

# ==================== الطيف الترددي (Spectrum / FFT) ====================

static func _average_spectrum(samples: PackedFloat32Array) -> PackedFloat32Array:
	var accum := PackedFloat32Array()
	accum.resize(SPECTRUM_BINS)
	var frames_used := 0
	var i := 0
	while i + FRAME_SIZE <= samples.size():
		var frame := samples.slice(i, i + FRAME_SIZE)
		if _rms(frame, 0, frame.size()) > SILENCE_RMS:
			var mags := _fft_magnitude(_apply_hamming(frame))
			var binned := _bin_spectrum(mags, SPECTRUM_BINS)
			for b in SPECTRUM_BINS:
				accum[b] += binned[b]
			frames_used += 1
		i += HOP_SIZE
	if frames_used > 0:
		for b in SPECTRUM_BINS:
			accum[b] /= frames_used
	return _normalize(accum)

static func _fft_magnitude(frame: PackedFloat32Array) -> PackedFloat32Array:
	var n := 1
	while n < frame.size():
		n *= 2
	var real := PackedFloat32Array()
	var imag := PackedFloat32Array()
	real.resize(n)
	imag.resize(n)
	for i in frame.size():
		real[i] = frame[i]
	_fft(real, imag)
	var half_n: int = n >> 1
	var mags := PackedFloat32Array()
	mags.resize(half_n)
	for i in half_n:
		mags[i] = sqrt(real[i] * real[i] + imag[i] * imag[i])
	return mags

## تحويل فورييه السريع (Cooley-Tukey Radix-2) - مكتوب يدويًا لأن Godot لا يوفره جاهزًا للمصفوفات
static func _fft(real: PackedFloat32Array, imag: PackedFloat32Array) -> void:
	var n := real.size()
	var j := 0
	for i in range(1, n):
		var bit := n >> 1
		while bit > 0 and (j & bit):
			j ^= bit
			bit >>= 1
		j ^= bit
		if i < j:
			var tr := real[i]; real[i] = real[j]; real[j] = tr
			var ti := imag[i]; imag[i] = imag[j]; imag[j] = ti
	var length := 2
	while length <= n:
		var ang: float = -2.0 * PI / length
		var wr := cos(ang)
		var wi := sin(ang)
		var half: int = length >> 1
		var i2 := 0
		while i2 < n:
			var cur_wr := 1.0
			var cur_wi := 0.0
			for k in half:
				var idx1 := i2 + k
				var idx2 := i2 + k + half
				var tr := real[idx2] * cur_wr - imag[idx2] * cur_wi
				var ti := real[idx2] * cur_wi + imag[idx2] * cur_wr
				real[idx2] = real[idx1] - tr
				imag[idx2] = imag[idx1] - ti
				real[idx1] += tr
				imag[idx1] += ti
				var new_wr := cur_wr * wr - cur_wi * wi
				var new_wi := cur_wr * wi + cur_wi * wr
				cur_wr = new_wr
				cur_wi = new_wi
			i2 += length
		length *= 2

## يجمع ترددات الـ FFT في نطاقات لوغاريتمية (تحاكي حساسية الأذن البشرية للترددات المنخفضة)
static func _bin_spectrum(mags: PackedFloat32Array, num_bins: int) -> PackedFloat32Array:
	var out := PackedFloat32Array()
	out.resize(num_bins)
	var total_bins := mags.size()
	for b in num_bins:
		var lo_frac: float = pow(float(b) / num_bins, 2.0)
		var hi_frac: float = pow(float(b + 1) / num_bins, 2.0)
		var lo_idx: int = int(lo_frac * total_bins)
		var hi_idx: int = maxi(lo_idx + 1, int(hi_frac * total_bins))
		hi_idx = mini(hi_idx, total_bins)
		var sum := 0.0
		for i in range(lo_idx, hi_idx):
			sum += mags[i]
		out[b] = sum / float(maxi(1, hi_idx - lo_idx))
	return out

static func _normalize(v: PackedFloat32Array) -> PackedFloat32Array:
	var total := 0.0
	for x in v:
		total += x
	if total <= 0.0:
		return v
	var out := PackedFloat32Array()
	out.resize(v.size())
	for i in v.size():
		out[i] = v[i] / total
	return out

static func _cosine_similarity(a: PackedFloat32Array, b: PackedFloat32Array) -> float:
	if a.size() != b.size() or a.size() == 0:
		return 0.0
	var dot := 0.0
	var na := 0.0
	var nb := 0.0
	for i in a.size():
		dot += a[i] * b[i]
		na += a[i] * a[i]
		nb += b[i] * b[i]
	if na <= 0.0 or nb <= 0.0:
		return 0.0
	return clampf(dot / (sqrt(na) * sqrt(nb)), 0.0, 1.0)

# ==================== مغلّف الطاقة الزمني (Envelope) ====================

static func _energy_envelope(samples: PackedFloat32Array, points: int) -> PackedFloat32Array:
	var out := PackedFloat32Array()
	out.resize(points)
	var chunk: int = maxi(1, int(samples.size() / float(points)))
	for p in points:
		out[p] = _rms(samples, p * chunk, chunk)
	return _normalize(out)

static func _envelope_score(a: PackedFloat32Array, b: PackedFloat32Array) -> float:
	if a.size() != b.size() or a.size() == 0:
		return 0.0
	var mean_a := 0.0
	var mean_b := 0.0
	for i in a.size():
		mean_a += a[i]
		mean_b += b[i]
	mean_a /= a.size()
	mean_b /= b.size()
	var num := 0.0
	var da := 0.0
	var db := 0.0
	for i in a.size():
		var xa := a[i] - mean_a
		var xb := b[i] - mean_b
		num += xa * xb
		da += xa * xa
		db += xb * xb
	if da <= 0.0 or db <= 0.0:
		return 0.5
	var corr: float = num / sqrt(da * db)
	return clampf((corr + 1.0) / 2.0, 0.0, 1.0)
