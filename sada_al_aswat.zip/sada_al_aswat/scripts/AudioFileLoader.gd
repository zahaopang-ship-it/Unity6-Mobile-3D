extends RefCounted
class_name AudioFileLoader
## يحمّل ملف صوت (wav / mp3 / ogg) مباشرة عبر FileAccess بدل الدالة العامة load().
##
## السبب: load() (أي ResourceLoader) يعتمد على فحص وجود الملف بطريقة مرتبطة
## بنظام استيراد المحرر، وهذا يعمل بشكل موثوق فقط مع ملفات res:// التي مرّت
## بعملية الاستيراد. أما الملفات التي تُنسخ في وقت التشغيل إلى user:// (كالأصوات
## المستوردة من اللاعب)، فقد يفشل load() في العثور عليها برسالة
## "Resource file not found" حتى لو كان الملف موجودًا فعليًا على القرص.
##
## الحل: نقرأ بايتات الملف مباشرة عبر FileAccess (يعمل بشكل موثوق مع أي
## مسار: res:// أو user:// أو مسار مطلق)، ثم نبني كائن AudioStream يدويًا.
## هذا يُستخدم الآن لكل الأصوات (المرفقة والمستوردة) لضمان سلوك موحّد.

static func load_audio_stream(path: String) -> AudioStream:
	var ext: String = path.get_extension().to_lower()
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		push_warning("تعذّر فتح الملف الصوتي: %s (خطأ رقم %d)" % [path, FileAccess.get_open_error()])
		return null
	var bytes: PackedByteArray = file.get_buffer(file.get_length())
	file.close()
	if bytes.is_empty():
		return null

	match ext:
		"mp3":
			var stream := AudioStreamMP3.new()
			stream.data = bytes
			return stream
		"ogg":
			return AudioStreamOggVorbis.load_from_buffer(bytes)
		"wav":
			return _parse_wav(bytes)
		_:
			return null

## قارئ WAV/RIFF مبسّط: يقرأ الرأس يدويًا لاستخراج معدل العينة وعدد القنوات
## وعمق البت، ثم يبني AudioStreamWAV من بيانات PCM الخام مباشرة - لا نعتمد
## على أي محمّل جاهز من Godot لهذه الخطوة.
static func _parse_wav(bytes: PackedByteArray) -> AudioStreamWAV:
	if bytes.size() < 44:
		return null
	if bytes.slice(0, 4).get_string_from_ascii() != "RIFF":
		return null
	if bytes.slice(8, 12).get_string_from_ascii() != "WAVE":
		return null

	var channels: int = 1
	var sample_rate: int = 44100
	var bits_per_sample: int = 16
	var pcm_data := PackedByteArray()
	var found_fmt := false
	var found_data := false

	var pos: int = 12
	while pos + 8 <= bytes.size():
		var chunk_id: String = bytes.slice(pos, pos + 4).get_string_from_ascii()
		var chunk_size: int = bytes.decode_u32(pos + 4)
		var chunk_start: int = pos + 8

		if chunk_id == "fmt ":
			channels = bytes.decode_u16(chunk_start + 2)
			sample_rate = bytes.decode_u32(chunk_start + 4)
			bits_per_sample = bytes.decode_u16(chunk_start + 14)
			found_fmt = true
		elif chunk_id == "data":
			var end: int = mini(chunk_start + chunk_size, bytes.size())
			pcm_data = bytes.slice(chunk_start, end)
			found_data = true

		pos = chunk_start + chunk_size
		if chunk_size % 2 == 1:
			pos += 1 # محاذاة بايت زوجية إلزامية في صيغة RIFF

	if not found_fmt or not found_data or pcm_data.is_empty():
		return null

	var stream := AudioStreamWAV.new()
	stream.data = pcm_data
	stream.mix_rate = sample_rate
	stream.stereo = channels >= 2
	stream.format = AudioStreamWAV.FORMAT_16_BITS if bits_per_sample == 16 else AudioStreamWAV.FORMAT_8_BITS
	return stream
