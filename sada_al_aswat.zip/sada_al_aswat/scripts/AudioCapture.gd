extends Node
class_name AudioCapture
## يلتقط عينات صوتية خام (Mono PCM) في الوقت الحقيقي عبر AudioEffectCapture.
##
## الفكرة: بدل قراءة بايتات ملف wav يدويًا (وهو ما كان يحصر الدعم على wav فقط)،
## نلتقط الصوت *بعد* أن يفك محرك Godot تشفيره ويشغّله عبر باص صوتي (Bus).
## هذا يعني أن أي صيغة يدعمها Godot للتشغيل (wav, mp3, ogg...) تصبح قابلة
## للتحليل تلقائيًا بدون أي كود خاص بكل صيغة - المصدر لا يهم، فقط الباص.
##
## باصان منفصلان:
##  - OriginalCapture: غير مكتوم (يُسمع صوته للاعبين) - لالتقاط الصوت الأصلي أثناء تشغيله.
##  - MicCapture: مكتوم (حتى لا يسمع اللاعبون صدى أصواتهم) - لالتقاط صوت المايكروفون.

const ORIGINAL_BUS := "OriginalCapture"
const MIC_BUS := "MicCapture"
const CAPTURE_BUFFER_SECONDS := 2.0

var original_effect: AudioEffectCapture
var mic_effect: AudioEffectCapture
var mic_player: AudioStreamPlayer

func _ready() -> void:
	original_effect = _setup_bus(ORIGINAL_BUS, false)
	mic_effect = _setup_bus(MIC_BUS, true)
	mic_player = AudioStreamPlayer.new()
	mic_player.stream = AudioStreamMicrophone.new()
	mic_player.bus = MIC_BUS
	add_child(mic_player)

func _setup_bus(bus_name: String, muted: bool) -> AudioEffectCapture:
	var idx: int = AudioServer.get_bus_index(bus_name)
	if idx == -1:
		AudioServer.add_bus()
		idx = AudioServer.bus_count - 1
		AudioServer.set_bus_name(idx, bus_name)
		AudioServer.set_bus_mute(idx, muted)
	var effect := AudioEffectCapture.new()
	effect.buffer_length = CAPTURE_BUFFER_SECONDS
	AudioServer.add_bus_effect(idx, effect)
	return effect

## يجب استدعاؤها مرة واحدة على AudioStreamPlayer الذي سيشغّل الصوت الأصلي
## حتى يُوجَّه صوته إلى باص الالتقاط الصحيح.
func prepare_original_player(player: AudioStreamPlayer) -> void:
	player.bus = ORIGINAL_BUS

func clear_original_buffer() -> void:
	_clear(original_effect)

func start_mic() -> void:
	_clear(mic_effect)
	mic_player.play()

func stop_mic() -> void:
	mic_player.stop()

func _clear(effect: AudioEffectCapture) -> void:
	if effect != null:
		effect.clear_buffer()

## يسحب كل الإطارات المتاحة حاليًا ويحوّلها من Stereo (Vector2) إلى Mono (float -1..1)
static func _drain(effect: AudioEffectCapture) -> PackedFloat32Array:
	var out := PackedFloat32Array()
	if effect == null:
		return out
	var available: int = effect.get_frames_available()
	if available <= 0:
		return out
	var frames: PackedVector2Array = effect.get_buffer(available)
	out.resize(frames.size())
	for i in frames.size():
		var f: Vector2 = frames[i]
		out[i] = (f.x + f.y) * 0.5
	return out

func poll_original() -> PackedFloat32Array:
	return _drain(original_effect)

func poll_mic() -> PackedFloat32Array:
	return _drain(mic_effect)
