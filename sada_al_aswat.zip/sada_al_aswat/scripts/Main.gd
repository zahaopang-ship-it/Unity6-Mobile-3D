extends Control

const PLAYER_SLOT_SCENE: PackedScene = preload("res://scenes/PlayerSlot.tscn")

const COUNTDOWN_SECONDS := 3

@onready var status_label: Label = $StatusLabel
@onready var player_count_row: HBoxContainer = $PlayerCountRow
@onready var count_label: Label = $PlayerCountRow/CountLabel
@onready var minus_button: Button = $PlayerCountRow/MinusButton
@onready var plus_button: Button = $PlayerCountRow/PlusButton
@onready var start_row: HBoxContainer = $StartRow
@onready var start_button: Button = $StartRow/StartButton
@onready var import_button: Button = $StartRow/ImportButton
@onready var import_dialog: FileDialog = $ImportDialog
@onready var record_button: Button = $RecordButton
@onready var countdown_label: Label = $CountdownLabel
@onready var original_player: AudioStreamPlayer = $OriginalPlayer
@onready var audio_capture: AudioCapture = $AudioCapture
@onready var players_container: HBoxContainer = $PlayersContainer
@onready var waveform_view: WaveformView = $WaveformPanel/WaveformView

var player_slots: Array[PlayerSlot] = []
var current_player_id: int = -1

var mix_rate: int = 44100
var round_duration: float = 0.0

var original_full_samples: PackedFloat32Array = PackedFloat32Array()
var mic_full_samples: PackedFloat32Array = PackedFloat32Array()
var mic_samples_written: int = 0

var is_capturing_original: bool = false
var is_recording: bool = false

var original_timer: Timer
var record_timer: Timer

func _ready() -> void:
	mix_rate = int(AudioServer.get_mix_rate())
	audio_capture.prepare_original_player(original_player)

	minus_button.pressed.connect(_on_minus_pressed)
	plus_button.pressed.connect(_on_plus_pressed)
	_refresh_player_count_ui()

	start_button.pressed.connect(_on_start_pressed)
	import_button.pressed.connect(_on_import_pressed)
	import_dialog.file_selected.connect(_on_import_file_selected)
	record_button.pressed.connect(_on_record_pressed)

	GameManager.round_started.connect(_on_round_started)
	GameManager.player_turn.connect(_on_player_turn)
	GameManager.player_result.connect(_on_player_result)
	GameManager.round_ended.connect(_on_round_ended)

	original_timer = Timer.new()
	original_timer.one_shot = true
	original_timer.timeout.connect(_on_original_capture_timeout)
	add_child(original_timer)

	record_timer = Timer.new()
	record_timer.one_shot = true
	record_timer.timeout.connect(_on_record_timeout)
	add_child(record_timer)

	if not GameManager.has_sounds():
		status_label.text = "ضع ملفات صوت (wav / mp3 / ogg) داخل مجلد sounds ثم أعد تشغيل المشروع"
		start_button.disabled = true

## يُستدعى كل إطار فقط أثناء التقاط الصوت الأصلي أو تسجيل اللاعب،
## ويقوم بسحب العينات الجديدة أولًا بأول (وليس دفعة واحدة في النهاية)
## حتى تظهر الموجة على الشاشة لحظيًا مع الكلام.
func _process(_delta: float) -> void:
	if is_capturing_original:
		var chunk := audio_capture.poll_original()
		if chunk.size() > 0:
			original_full_samples.append_array(chunk)
		if round_duration > 0.0:
			var progress: float = original_player.get_playback_position() / round_duration
			waveform_view.set_playhead(progress)

	if is_recording:
		var chunk := audio_capture.poll_mic()
		if chunk.size() > 0:
			var start_sample: int = mic_samples_written
			mic_full_samples.append_array(chunk)
			mic_samples_written += chunk.size()
			_update_live_waveform(start_sample, chunk.size())
		if round_duration > 0.0 and mix_rate > 0:
			var progress: float = float(mic_samples_written) / (round_duration * mix_rate)
			waveform_view.set_playhead(progress)

# ==================== اختيار عدد اللاعبين ====================

func _refresh_player_count_ui() -> void:
	count_label.text = str(GameManager.num_players)
	minus_button.disabled = GameManager.num_players <= GameManager.MIN_PLAYERS
	plus_button.disabled = GameManager.num_players >= GameManager.MAX_PLAYERS

func _on_minus_pressed() -> void:
	GameManager.set_num_players(GameManager.num_players - 1)
	_refresh_player_count_ui()

func _on_plus_pressed() -> void:
	GameManager.set_num_players(GameManager.num_players + 1)
	_refresh_player_count_ui()

# ==================== استيراد صوت خارجي ====================

func _on_import_pressed() -> void:
	import_dialog.popup_centered()

## يُستدعى بعد أن يختار اللاعب ملفًا صوتيًا من نافذة النظام
func _on_import_file_selected(path: String) -> void:
	var dest_path: String = GameManager.import_sound_file(path)
	if dest_path == "":
		status_label.text = "⚠️ تعذّر استيراد الملف. تأكد أنه بصيغة wav أو mp3 أو ogg"
		return
	status_label.text = "✅ تم استيراد الصوت: %s" % dest_path.get_file()
	if GameManager.has_sounds():
		start_button.disabled = false

func _spawn_player_slots() -> void:
	for child in players_container.get_children():
		child.queue_free()
	player_slots.clear()
	for i in GameManager.num_players:
		var slot: PlayerSlot = PLAYER_SLOT_SCENE.instantiate()
		players_container.add_child(slot)
		slot.set_player_id(i)
		player_slots.append(slot)

# ==================== بدء الجولة ====================

func _on_start_pressed() -> void:
	player_count_row.visible = false
	start_row.visible = false
	_spawn_player_slots()
	waveform_view.reset_original()
	waveform_view.reset_live()
	waveform_view.hide_playhead()
	GameManager.start_round()

func _on_round_started(sound_path: String) -> void:
	status_label.text = "🔊 استمعوا جيدًا للصوت..."
	var stream: AudioStream = AudioFileLoader.load_audio_stream(sound_path)
	if stream == null:
		# الملف تالف أو غير مقروء: نستبعده نهائيًا ونجرّب صوتًا آخر تلقائيًا
		GameManager.remove_sound(sound_path)
		if GameManager.has_sounds():
			status_label.text = "⚠️ تعذّر تشغيل أحد الأصوات، جارِ تجربة صوت آخر..."
			GameManager.start_round()
		else:
			status_label.text = "⚠️ لا توجد أصوات صالحة. أضف ملفات wav/mp3/ogg سليمة."
			_on_round_ended_reset_ui()
		return

	var natural_length: float = stream.get_length()
	if natural_length <= 0.0:
		natural_length = GameManager.MAX_ORIGINAL_SECONDS
	round_duration = minf(natural_length, GameManager.MAX_ORIGINAL_SECONDS)

	original_full_samples = PackedFloat32Array()
	audio_capture.clear_original_buffer()
	waveform_view.reset_live()

	original_player.stream = stream
	original_player.play()
	is_capturing_original = true

	if not original_player.finished.is_connected(_on_original_playback_finished):
		original_player.finished.connect(_on_original_playback_finished, CONNECT_ONE_SHOT)
	original_timer.start(round_duration)

func _on_original_playback_finished() -> void:
	_stop_original_capture()

## تُستخدم فقط عندما تفشل كل الأصوات المتاحة ولا يمكن متابعة الجولة
func _on_round_ended_reset_ui() -> void:
	start_button.text = "ابدأ الجولة"
	start_row.visible = true
	player_count_row.visible = true

func _on_original_capture_timeout() -> void:
	if original_player.playing:
		original_player.stop()
	_stop_original_capture()

func _stop_original_capture() -> void:
	if not is_capturing_original:
		return
	is_capturing_original = false
	original_timer.stop()
	if original_player.playing:
		original_player.stop()

	var last_chunk := audio_capture.poll_original()
	if last_chunk.size() > 0:
		original_full_samples.append_array(last_chunk)

	waveform_view.set_original_from_samples(original_full_samples)
	waveform_view.hide_playhead()
	GameManager.begin_turns()

# ==================== دور اللاعب والتسجيل ====================

func _on_player_turn(player_id: int) -> void:
	current_player_id = player_id
	for i in player_slots.size():
		player_slots[i].set_active(i == player_id)
	status_label.text = "🎭 دور اللاعب %d — اضغط زر التسجيل وقلّد الصوت" % (player_id + 1)
	record_button.visible = true
	record_button.disabled = false
	waveform_view.reset_live()
	waveform_view.hide_playhead()

## بضغطة واحدة فقط: يبدأ عد تنازلي 3 ثوانٍ، ثم يبدأ التسجيل فعليًا،
## ويتوقف تلقائيًا بعد مرور مدة الصوت الأصلي بالضبط
func _on_record_pressed() -> void:
	record_button.disabled = true
	await _run_countdown()
	_begin_actual_recording()

func _run_countdown() -> void:
	countdown_label.visible = true
	for i in range(COUNTDOWN_SECONDS, 0, -1):
		countdown_label.text = str(i)
		status_label.text = "استعد للتقليد..."
		await get_tree().create_timer(1.0).timeout
	countdown_label.visible = false

func _begin_actual_recording() -> void:
	status_label.text = "🎙 جارِ التسجيل... تكلّم الآن!"

	mic_full_samples = PackedFloat32Array()
	mic_samples_written = 0
	waveform_view.reset_live()

	audio_capture.start_mic()
	is_recording = true
	record_timer.start(round_duration)

func _on_record_timeout() -> void:
	_finish_recording()

func _finish_recording() -> void:
	if not is_recording:
		return
	is_recording = false
	record_timer.stop()
	audio_capture.stop_mic()

	var last_chunk := audio_capture.poll_mic()
	if last_chunk.size() > 0:
		mic_full_samples.append_array(last_chunk)
		mic_samples_written += last_chunk.size()

	status_label.text = "🧮 جارِ تحليل التطابق الصوتي..."
	waveform_view.hide_playhead()
	var percentage: float = VoiceAnalyzer.compute_similarity(
		original_full_samples, mix_rate,
		mic_full_samples, mix_rate
	)
	GameManager.submit_attempt(current_player_id, percentage)

## يحدّث نقاط الموجة الحية المتأثرة بهذه الدفعة الجديدة من العينات فقط (وليس كل الموجة)
func _update_live_waveform(start_sample: int, chunk_size: int) -> void:
	if round_duration <= 0.0 or mix_rate <= 0 or chunk_size <= 0:
		return
	var total_samples: float = round_duration * mix_rate
	if total_samples <= 0.0:
		return

	var points: int = WaveformView.DISPLAY_POINTS
	var start_slot: int = clampi(int(float(start_sample) / total_samples * points), 0, points - 1)
	var end_slot: int = clampi(int(float(start_sample + chunk_size) / total_samples * points), 0, points - 1)

	var peak: float = 0.0
	var from_i: int = mic_full_samples.size() - chunk_size
	for i in range(from_i, mic_full_samples.size()):
		var av: float = absf(mic_full_samples[i])
		if av > peak:
			peak = av

	for slot in range(start_slot, end_slot + 1):
		waveform_view.set_live_peak(slot, peak)

# ==================== النتائج ====================

func _on_player_result(player_id: int, percentage: float) -> void:
	player_slots[player_id].show_score(percentage)
	player_slots[player_id].set_active(false)
	record_button.visible = false

func _on_round_ended(results: Array[Dictionary]) -> void:
	var winner: Dictionary = results[0]
	var winner_id: int = winner["id"]
	var winner_percentage: float = winner["percentage"]
	player_slots[winner_id].mark_winner()
	status_label.text = "🏆 الفائز: اللاعب %d بنسبة تطابق %d%%" % [winner_id + 1, roundi(winner_percentage)]
	start_button.text = "جولة جديدة 🔄"
	start_row.visible = true
	player_count_row.visible = true
