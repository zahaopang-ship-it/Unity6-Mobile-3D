extends Control
class_name WaveformView
## يرسم موجتين متراكبتين على نفس المحور الزمني:
##  - الموجة الزرقاء: الصوت الأصلي (تُرسم دفعة واحدة بعد انتهاء تشغيله)
##  - الموجة البرتقالية: محاولة اللاعب (تتحدث حيًّا مباشرة أثناء التسجيل)
## تراكب الموجتين يعطي اللاعبين إحساسًا بصريًا فوريًا بمدى تطابق الإيقاع والشدة،
## أما النسبة الدقيقة الحقيقية فتُحسب رياضيًا في VoiceAnalyzer.gd.
##
## بالإضافة إلى خط مؤشر أحمر متحرك (playhead) يوضح لحظيًا أين وصل التشغيل/
## التسجيل على طول المحور الزمني، تمامًا مثل شريط تشغيل الصوت في تطبيقات
## التواصل الاجتماعي.

const DISPLAY_POINTS := 200

var original_peaks: PackedFloat32Array = PackedFloat32Array()
var live_peaks: PackedFloat32Array = PackedFloat32Array()

var show_playhead: bool = false
var playhead_progress: float = 0.0 # من 0.0 إلى 1.0 على طول العرض

func _ready() -> void:
	original_peaks.resize(DISPLAY_POINTS)
	live_peaks.resize(DISPLAY_POINTS)

func reset_original() -> void:
	original_peaks.fill(0.0)
	queue_redraw()

func reset_live() -> void:
	live_peaks.fill(0.0)
	queue_redraw()

## يحوّل مصفوفة العينات الكاملة إلى DISPLAY_POINTS قيمة "ذروة" لعرضها كموجة ثابتة
func set_original_from_samples(samples: PackedFloat32Array) -> void:
	original_peaks = _downsample_peaks(samples, DISPLAY_POINTS)
	queue_redraw()

## يحدّث نقطة واحدة أو أكثر من الموجة الحية فورًا أثناء التسجيل (بدون إعادة حساب كل شيء)
func set_live_peak(index: int, value: float) -> void:
	if index < 0 or index >= live_peaks.size():
		return
	if value > live_peaks[index]:
		live_peaks[index] = value
	queue_redraw()

## يحرّك خط المؤشر الأحمر إلى نسبة معيّنة (0.0 يسار، 1.0 يمين) - يُستدعى كل
## إطار أثناء تشغيل الصوت الأصلي أو أثناء تسجيل اللاعب، حتى يعرف بالضبط أين
## وصل مقارنة بالصوت الأصلي.
func set_playhead(progress: float) -> void:
	show_playhead = true
	playhead_progress = clampf(progress, 0.0, 1.0)
	queue_redraw()

func hide_playhead() -> void:
	show_playhead = false
	queue_redraw()

static func _downsample_peaks(samples: PackedFloat32Array, points: int) -> PackedFloat32Array:
	var out := PackedFloat32Array()
	out.resize(points)
	if samples.is_empty():
		return out
	var chunk: int = maxi(1, int(samples.size() / float(points)))
	for p in points:
		var from_i: int = p * chunk
		var to_i: int = mini(from_i + chunk, samples.size())
		var peak: float = 0.0
		for i in range(from_i, to_i):
			var av: float = absf(samples[i])
			if av > peak:
				peak = av
		out[p] = peak
	return out

func _draw() -> void:
	var w: float = size.x
	var h: float = size.y
	var mid: float = h / 2.0
	draw_line(Vector2(0, mid), Vector2(w, mid), Color(1, 1, 1, 0.15), 1.0)
	_draw_peaks(original_peaks, Color(0.35, 0.65, 1.0, 0.9), w, mid)
	_draw_peaks(live_peaks, Color(1.0, 0.55, 0.2, 0.9), w, mid)
	if show_playhead:
		_draw_playhead(w, h)

func _draw_peaks(peaks: PackedFloat32Array, color: Color, w: float, mid: float) -> void:
	if peaks.size() < 2:
		return
	var step: float = w / float(peaks.size())
	var bar_width: float = maxf(step * 0.8, 1.0)
	for i in peaks.size():
		var amp: float = clampf(peaks[i], 0.0, 1.0) * mid * 0.95
		if amp < 1.0:
			amp = 1.0
		var x: float = i * step + step * 0.5
		draw_line(Vector2(x, mid - amp), Vector2(x, mid + amp), color, bar_width)

func _draw_playhead(w: float, h: float) -> void:
	var x: float = playhead_progress * w
	# توهّج خفيف خلف الخط لإبرازه، ثم الخط الأحمر الصريح فوقه
	draw_line(Vector2(x, 0), Vector2(x, h), Color(1.0, 0.15, 0.15, 0.35), 6.0)
	draw_line(Vector2(x, 0), Vector2(x, h), Color(1.0, 0.2, 0.2, 1.0), 2.5)
	# مقبض صغير أعلى الخط يشبه رأس مؤشر التشغيل
	var handle_radius: float = 6.0
	draw_circle(Vector2(x, handle_radius), handle_radius, Color(1.0, 0.2, 0.2, 1.0))

