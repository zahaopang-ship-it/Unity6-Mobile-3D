extends Node
## مدير اللعبة: مسؤول فقط عن "الحالة والمنطق" (من دوره الآن، ما هي النتائج...)
## لا يلمس الواجهة أو الصوت مباشرة - المشهد Main.gd هو من يستمع لإشاراته وينفذها.

signal round_started(sound_path: String)
signal player_turn(player_id: int)
signal player_result(player_id: int, percentage: float)
signal round_ended(results: Array[Dictionary])

## res://sounds هو المجلد الذي يُشحَن مع المشروع نفسه (أصوات جاهزة من المطوّر).
## user://sounds هو مجلد بيانات المستخدم الدائم على جهازه - هنا تُنسخ الأصوات
## التي يستوردها اللاعب من هاتفه/حاسوبه عبر زر "استيراد صوت"، وتبقى محفوظة
## بين مرات تشغيل اللعبة (على عكس res:// الذي يكون للقراءة فقط بعد التصدير).
const BUNDLED_SOUNDS_DIR := "res://sounds"
const USER_SOUNDS_DIR := "user://sounds"
const ALLOWED_EXTENSIONS := ["wav", "mp3", "ogg"]

const MAX_ORIGINAL_SECONDS := 5.0
const MIN_PLAYERS := 2
const MAX_PLAYERS := 5
const DEFAULT_PLAYERS := 4

var sound_files: Array[String] = []
var num_players: int = DEFAULT_PLAYERS
var current_sound_path: String = ""
var scores: Dictionary = {}
var turn_order: Array[int] = []
var current_turn_i: int = 0

func _ready() -> void:
	_ensure_user_sounds_dir()
	_scan_sounds()

func _ensure_user_sounds_dir() -> void:
	if not DirAccess.dir_exists_absolute(USER_SOUNDS_DIR):
		DirAccess.make_dir_recursive_absolute(USER_SOUNDS_DIR)

## يبحث في مجلدي الأصوات (المرفق مع المشروع + المستوردة من المستخدم) عن أي
## ملف بصيغة wav / mp3 / ogg ليستخدمه كصوت للتقليد. لا يوجد أي قيد آخر على
## الصيغة: التحليل يتم عبر التقاط الصوت من محرك التشغيل نفسه (AudioCapture.gd).
func _scan_sounds() -> void:
	sound_files.clear()
	_scan_dir(BUNDLED_SOUNDS_DIR)
	_scan_dir(USER_SOUNDS_DIR)

func _scan_dir(path: String) -> void:
	var dir := DirAccess.open(path)
	if dir == null:
		return
	dir.list_dir_begin()
	var f := dir.get_next()
	while f != "":
		if not dir.current_is_dir() and _has_allowed_extension(f):
			sound_files.append(path + "/" + f)
		f = dir.get_next()
	dir.list_dir_end()

func _has_allowed_extension(file_name: String) -> bool:
	var ext: String = file_name.get_extension().to_lower()
	return ALLOWED_EXTENSIONS.has(ext)

func has_sounds() -> bool:
	return sound_files.size() > 0

## ينسخ ملف صوت خارجي (اخترته اللاعب عبر نافذة الاستيراد) إلى مجلد بيانات
## المستخدم الدائم، ويضيفه فورًا إلى قائمة الأصوات المتاحة في هذه الجلسة وما بعدها.
## يرجع المسار الجديد عند النجاح، أو نص فارغ عند الفشل.
func import_sound_file(source_path: String) -> String:
	if not _has_allowed_extension(source_path):
		return ""
	_ensure_user_sounds_dir()

	var file_name: String = source_path.get_file()
	var base_name: String = file_name.get_basename()
	var ext: String = file_name.get_extension()
	var dest_path: String = USER_SOUNDS_DIR + "/" + file_name
	var counter := 1
	while FileAccess.file_exists(dest_path):
		file_name = "%s_%d.%s" % [base_name, counter, ext]
		dest_path = USER_SOUNDS_DIR + "/" + file_name
		counter += 1

	var err: int = DirAccess.copy_absolute(source_path, dest_path)
	if err != OK:
		return ""

	# تحقّق فعلي: هل يمكن قراءة الملف المنسوخ وبناء صوت منه؟ (نفس الطريقة
	# التي ستُستخدم لاحقًا أثناء اللعب) لتفادي إضافة ملف تالف أو غير مدعوم.
	if AudioFileLoader.load_audio_stream(dest_path) == null:
		DirAccess.remove_absolute(dest_path)
		return ""

	if not sound_files.has(dest_path):
		sound_files.append(dest_path)
	return dest_path

## تُزيل صوتًا من القائمة (يُستخدم عند اكتشاف أن ملفًا تالف أو تعذّر تشغيله أثناء اللعب)
func remove_sound(path: String) -> void:
	sound_files.erase(path)

func set_num_players(n: int) -> void:
	num_players = clampi(n, MIN_PLAYERS, MAX_PLAYERS)

func start_round() -> void:
	scores.clear()
	turn_order.clear()
	for i in num_players:
		turn_order.append(i)
	turn_order.shuffle()
	current_turn_i = 0
	current_sound_path = sound_files[randi() % sound_files.size()]
	round_started.emit(current_sound_path)

func begin_turns() -> void:
	_next_turn()

func _next_turn() -> void:
	if current_turn_i >= turn_order.size():
		_finish_round()
		return
	var pid: int = turn_order[current_turn_i]
	player_turn.emit(pid)

## تُستدعى من Main.gd بعد أن ينتهي التحليل الصوتي الفعلي لمحاولة اللاعب
func submit_attempt(player_id: int, percentage: float) -> void:
	scores[player_id] = percentage
	player_result.emit(player_id, percentage)
	current_turn_i += 1
	_next_turn()

func _finish_round() -> void:
	var results: Array[Dictionary] = []
	for pid in scores.keys():
		results.append({"id": pid, "percentage": scores[pid]})
	results.sort_custom(func(a, b): return a["percentage"] > b["percentage"])
	round_ended.emit(results)
